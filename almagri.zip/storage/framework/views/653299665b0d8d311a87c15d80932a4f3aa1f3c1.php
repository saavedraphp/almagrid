

<?php $__env->startSection('content'); ?>

<div class="container">
<h2>Lista de Productos 
  <a href="productos/create"> <button type="button" class="btn btn-success float-right"><?php echo e(MiConstantes::NUEVO); ?></button></a>
  

</h2>

<?php if($search): ?>
<h6><div class="alert alert-primary" role="alert">
  Resultado de la busqueda '<?php echo e($search); ?>'
  </div>
</h6>
<?php endif; ?>


<?php if(Session::get('operacion')=='1'): ?>
<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <?php echo e(Session::get('message')); ?>

</div>
<?php endif; ?>

<?php if(Session::get('operacion')=='0'): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <?php echo e(Session::get('message')); ?>

  </div>

<?php endif; ?>

<form action="" method="GET" class="card-header" >
<div class="form-outline">
  <div class="form-row">
    
    <div class="form-group col-md-5" >
      <div class="input-group input-group-sm">
          <input class="form-control form-control-navbar" type="search" placeholder="Buscar" aria-label="Search" name="search">
          <div class="input-group-append">
              <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
              </button>
          </div>
      </div>

    </div>
  </div>

  </div>
 
</form>
<br>

<table class="table table-hover" >
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">SKU</th>
      <th scope="col">Producto</th>
      <th scope="col">Total</th>
      <th scope="col">F.Vencimiento</th>
      <th scope="col">Empresa</th>
    </tr>
  </thead>
  <tbody id="userList">
  	<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr v-for>
      <th > <?php echo e($producto->prod_id); ?> </th>
      <th > <?php echo e($producto->prod_sku); ?> </th>
      <td><?php echo e($producto->prod_nombre); ?></td>
      <td><?php echo e($producto->prod_stock); ?></td>
      <td><?php echo e($producto->prod_fecha_vencimiento); ?></td>
      <td><?php echo e($producto->empr_nombre); ?></td>

      <td>


        <form action="<?php echo e(route('productos.destroy',$producto->prod_id)); ?>" method="POST" id="frm_destroy<?php echo e($producto->prod_id); ?>">
          <?php echo method_field('DELETE'); ?>
          <?php echo csrf_field(); ?>



         <a href="<?php echo e(route('productos.edit',$producto->prod_id)); ?>" title="<?php echo e(MiConstantes::EDITAR); ?>"> <i class="far fa-edit" ></i></a> |
         <a href="javascript:document.getElementById('frm_destroy<?php echo e($producto->prod_id); ?>').submit();" onclick="return confirm('Estas Seguro de Borrar el Registro Id:<?php echo e($producto->prod_id); ?>');" title="<?php echo e(MiConstantes::ELIMINAR); ?>"><i class="fas fa-trash-alt"></i></a>

        </form>

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<div class="row">
  <div class="mx-auto"><?php echo e($productos->links()); ?></div>
</div>
</div>
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\almagri\resources\views/productos/index.blade.php ENDPATH**/ ?>