

<?php $__env->startSection('content'); ?>
<?php $empresas = app('App\Services\Empresas'); ?>
<?php $presentaciones = app('App\Services\Presentaciones'); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/productos.js')); ?>" ></script>
<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

 

<script>
	$(document).ready(function(){
		var date_input=$('input[name="fecha_vencimiento"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'yyyy-mm-dd',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})

</script>
<?php $__env->stopSection(); ?>

<div class="container">

<div class="row">
<div class="col-md-8">
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <h4>Por Favor corriga los siguientes errores   </h4>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
   <?php endif; ?>

<form action="/admin/productos" method="POST" id="frm_formulario" @submit="checkForm">
<?php echo csrf_field(); ?>

  <p v-if="errors.length">
    <b style="color: red;">Por favor, corrija el(los) siguiente(s) error(es):</b>
    <ul>
      <li v-for="error in errors">{{error}}</li>
    </ul>
  </p>

  <h2>[Nuevo]  </h2>



  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="producto">Producto *</label>
      <input type="text" class="form-control" v-model="producto" name="producto" id="producto" placeholder="Nombre" value="<?php echo e(old('producto')); ?>">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">P. Inventario</label>
      <input type="text" class="form-control" v-model="sku" name="sku" id="sku_id" placeholder="SKU" value="<?php echo e(old('sku')); ?>">
    </div>
  </div>


  




  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="cbo_presentacion">Unidad de Medida</label>

      <select class="form-control" aria-label="Default select example" name="cbo_presentacion" id="cbo_presentacion_id"
      v-model="cbo_presentacion_id">
      <?php echo e($guion  =""); ?>;
        <?php $__currentLoopData = $presentaciones->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
          <option value=<?php echo e($index); ?>  <?php if($index =='5'): ?> selected <?php endif; ?>><?php echo e($value); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
 
   </div>


    <div class="form-group col-md-6">
        <label for="inputAddress">Peso neto KG</label>
        <input type="number" class="form-control" id="peso_id" placeholder="Peso" name="peso" value="<?php echo e(old('peso')); ?>">
    </div>
    
  </div>



 

 
  <div class="form-group">
    
  <label for="empresa_id">Empresa</label>
      <select v-model="empresa_id" id="empresa_id" data-old="<?php echo e(old('cbo_empresa')); ?>"
      name="cbo_empresa"  class="form-control">
      <?php echo e($guion  =""); ?>;
        <?php $__currentLoopData = $empresas->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
          <option value="<?php echo e($index); ?>" ><?php echo e($index.$guion.$value); ?></option>
            <?php echo e($guion  =" - "); ?>;
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </select>
 
  </div>


  <div class="form-row">
    <div class="form-group col-md-6">
        <label for="inputAddress">Lote</label>
        <input type="number" class="form-control" id="lote_id" placeholder="Lote" name="lote" value="<?php echo e(old('lote')); ?>">
 
   </div>


    <div class="form-group col-md-6">
        <label for="inputAddress">Fecha Vencimiento</label>
        <input  class="form-control"    id="fecha_id"  name="fecha_vencimiento"  placeholder="YYYY-MM-DD"  value="<?php echo e(old('peso')); ?>">
        

    </div>
    
  </div>


 


    <div class="form-group">
      <label for="inputEmail4">Descripción</label>
      <textarea class="form-control" id="comentario_id" name="comentario" rows="3" placeholder="Descripción"></textarea>
    </div>
 



  <button type="submit" class="btn btn-primary">Registrar</button>
  <button type="reset" class="btn btn-danger">Cancelar</button>

</form>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\almagri\resources\views/productos/create.blade.php ENDPATH**/ ?>