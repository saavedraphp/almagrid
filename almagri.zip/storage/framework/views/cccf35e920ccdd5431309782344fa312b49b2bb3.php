

<?php $__env->startSection('content'); ?>


 
 

<h2>Lista de Actas
<a href="actas/create-despacho"> <button type="button" class="btn btn-danger float-right">Add Despacho</button></a>
<a href="actas/create"> <button type="button" class="btn btn-success float-right mr-3"><?php echo e(MiConstantes::NUEVO); ?></button></a>  

 </h2>


<?php if($search): ?>
<h6><div class="alert alert-primary" role="alert">
  Resultado de la busqueda '<?php echo e($search); ?>'
  </div>
</h6>
<?php endif; ?>

 

<?php if(Session::get('operacion')=='1'): ?>
<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <?php echo e(Session::get('message')); ?>

</div>
<?php endif; ?>

<?php if(Session::get('operacion')=='0'): ?>
  <div class="alert alert-danger alert-dismissible" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <?php echo e(Session::get('message')); ?>

  </div>

<?php endif; ?>

<form action="" method="GET">
<div class="form-outline">
  <div class="form-row">
    
    <div class="form-group col-md-5" >
      <div class="input-group input-group-sm">
          <input class="form-control form-control-navbar" type="search" placeholder="Nro Documento" aria-label="Search" name="nro_documento">
          <div class="input-group-append">
              <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
              </button>
          </div>
      </div>

    </div>
    
    <div class="form-group col-md-1">
    </div>

    <div class="form-group col-md-6">
          <div class="form-check form-check-inline">
          
        <input
          class="form-check-input"
          type="radio"
          name="rbo_lista"
          id="inlineRadio1"
          value="DESPAC" 
          onchange="this.form.submit()" 
          
        />
        <label class="form-check-label" for="inlineRadio1">Despacho</label>
      </div>

      <div class="form-check form-check-inline">
        <input
          class="form-check-input"
          type="radio"
          name="rbo_lista"
          id="inlineRadio2"
          value="ALMACE"
          onchange="this.form.submit()" 
          

        />
        <label class="form-check-label" for="inlineRadio2">Almacenamiento</label>
      </div>

      <div class="form-check form-check-inline">
        <input
          class="form-check-input"
          type="radio"
          name="rbo_lista"
          id="inlineRadio3"
          value="ALL"
          onchange="this.form.submit()" 
          
        />
        <label class="form-check-label" for="inlineRadio2">Todos</label>
      </div>
      
    </div>

  </div>
</div>
</form>

<table class="table table-hover" >
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Empresa</th>
      <th scope="col">Tipo Movimiento</th>
      <th scope="col">Nombre</th>
       <th scope="col">Fecha de Creacion</th>      
      <th scope="col">Acciones</th>
    </tr>
  </thead>
  <tbody id="userList">
  	<?php $__currentLoopData = $actas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr v-for>
      <th scope="row"> <?php echo e($acta->acta_id); ?> </th>
      <td><?php echo e($acta->empr_nombre); ?></td>
      <td><?php echo e($acta->tipo_movimiento_codigo); ?></td>
      <td><?php echo e($acta->acta_sub_cliente); ?></td>
       <td><?php echo e(date('M d Y h:i:s', strtotime($acta->created_at))); ?></td>

      <td>


        <form action="<?php echo e(route('actas.destroy',$acta->acta_id)); ?>" method="POST" id="frm_destroy<?php echo e($acta->acta_id); ?>">
          <?php echo method_field('DELETE'); ?>
          <?php echo csrf_field(); ?>

 
         <a href="<?php echo e(route('actas.show',$acta->acta_id)); ?>" title="<?php echo e(MiConstantes::VER); ?>"><i class="far fa-eye"></i></a> |
         <a href="#" title="<?php echo e(MiConstantes::REPORTE); ?>"><i class="far fa-file-pdf"></i></a> |
         <a href="javascript:document.getElementById('frm_destroy<?php echo e($acta->acta_id); ?>').submit();" onclick="return confirm('Estas Seguro de Borrar el Registro Id:<?php echo e($acta->acta_id); ?>');" title="<?php echo e(MiConstantes::ELIMINAR); ?>"><i class="fas fa-trash-alt"></i></a>
         
     
        </form>

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<div class="row">
  <div class="mx-auto"><?php echo e($actas->links()); ?></div>
</div>
</div>
 <?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\almagri\resources\views/actas/index.blade.php ENDPATH**/ ?>