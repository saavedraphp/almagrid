<?php
namespace App;

class Constants {
   const TITULO = 'Sistema Almagri';

   //OPERACIONES
   const NUEVO = 'Nuevo';
   const CREAR = 'Crear';
   const EDITAR = 'Editar';
   const ELIMINAR = 'Eliminar';
   const REPORTE = 'Reporte';
   const VER = 'Ver';

   const ASIGNAR_CASILLAS = 'Casillas';
   const IMG_REPORTE = 'Imagen Reporte';

}