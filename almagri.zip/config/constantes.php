<?php
return [
    "TITULO" => "Sistema de Almacen",
    "iva" => 16,
    "anidado" => [
      "clave" => "valor",
      "otra_clave" => 4897,
      "una_mas" => 5.6
    ]
];